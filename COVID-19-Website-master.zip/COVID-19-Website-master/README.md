# COVID-19-Website
Hi, this is a simple static informational website.

To start the website, simple download or clone the project and open the 'index.html' file.

Happy coding :)
